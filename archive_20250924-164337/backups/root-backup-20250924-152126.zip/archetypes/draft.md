---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
draft: true
---

## {{ replace .Name "-" " " | title }}

เนื้อหาเริ่มต้น...

{{</* footnote */>}}
หมายเหตุเริ่มต้น
{{</* /footnote */>}}
