---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
draft: true
author: "{{ .Site.Params.author | default "บก.จุ๊กจิ๋ว" }}"
categories: []
tags: []
---

## Hook
(ประโยคเปิดเรื่อง)

## เนื้อหา
(เขียนเนื้อหาได้เลย)

