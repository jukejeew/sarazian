---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
draft: true
categories: []
tags: []
---

ย่อหน้าเปิด (hook) — 1–2 บรรทัดให้คนอยากอ่านต่อ

หัวใจของเรื่อง (3 ประเด็นสั้น ๆ)
- ประเด็น #1
- ประเด็น #2
- ประเด็น #3

สรุป / ชวนคิดต่อ 1 บรรทัด

{{< footer-note >}}
{{< credit >}}
{{< license >}}

